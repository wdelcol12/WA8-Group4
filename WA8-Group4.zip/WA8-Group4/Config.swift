//
//  Config.swift
//  WA8-Group4
//
//  Created by Rishabh Raj on 13/11/23.
//


import Foundation
class Configs{
    static let tableViewMessagesID = "tableViewMessagesID"
}

